import torch
import random
import torch.nn as nn

# SPUMix (Style-Paired Uncertainty-Aware Mixstyle)
class SPUMix(nn.Module):

    def __init__(self, p=0.5, alpha=0.1, eps=1e-6):

        # Args:
        #   p (float): probability of using SPUMix.
        #   alpha (float): parameter of the Beta distribution.
        #   eps (float): scaling parameter to avoid numerical issues.
        super().__init__()
        self.p = p
        self.beta = torch.distributions.Beta(alpha, alpha)
        self.eps = eps
        self.alpha = alpha
        self._activated = True

    def set_activation_status(self, status=True):
        self._activated = status

    def forward(self, x):
        if not self.training or not self._activated:
            return x
        if random.random() > self.p:
            return x

        B = x.size(0)
        mu = x.mean(dim=[2, 3], keepdim=True)
        var = x.var(dim=[2, 3], keepdim=True)
        sig = (var + self.eps).sqrt()
        mu, sig = mu.detach(), sig.detach()
        x_normed = (x - mu) / sig

        # Style-Paired
        style_feat = torch.cat([mu.view(B, -1), sig.view(B, -1)], dim=1)
        dist = torch.cdist(style_feat, style_feat, p=2)
        perm = dist.max(dim=1)[1]  # Pairing with the sample with the farthest style

        mu2, sig2 = mu[perm], sig[perm]

        # Uncertainty-Aware Adaptive Lambda
        softmax_x = torch.softmax(x_normed, dim=1)
        entropy = -(softmax_x * torch.log(softmax_x + 1e-6)).sum(dim=1, keepdim=True)
        entropy = entropy.mean(dim=[2, 3], keepdim=True)
        uncertainty_weight = torch.sigmoid(entropy)  # shape: [B, 1, 1, 1]

        lmdabeta = self.beta.sample((B, 1, 1, 1)).to(x.device)
        lmda = lmdabeta * uncertainty_weight + (1 - uncertainty_weight) * 0.5

        mu_mix = mu * lmda + mu2 * (1 - lmda)
        sig_mix = sig * lmda + sig2 * (1 - lmda)

        return x_normed * sig_mix + mu_mix 