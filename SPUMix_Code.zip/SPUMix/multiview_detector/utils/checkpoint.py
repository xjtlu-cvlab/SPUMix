import re
from collections import OrderedDict

import torch


# Target ResNet-18 + SPUMix Sequential layout used by MVDeTr.base:
# 0 conv1 | 1 SPUMix0 | 2 bn1 | 3 relu | 4 maxpool |
# 5 layer1 | 6 SPUMix1 | 7 layer2 | 8 SPUMix2 | 9 layer3 | 10 SPUMix3 | 11 layer4
_TARGET_BASE = {
    'conv1': 0,
    'bn1': 2,
    'layer1': 5,
    'layer2': 7,
    'layer3': 9,
    'layer4': 11,
}


def _classify_base_index(state_dict, idx):
    """Identify a Sequential base child by tensor shapes in the checkpoint."""
    prefix = f'base.{idx}.'
    keys = [k for k in state_dict if k.startswith(prefix)]
    if not keys:
        return None

    # BatchNorm: base.{idx}.weight with 1-D shape and running_mean present
    if f'base.{idx}.running_mean' in state_dict:
        return 'bn1'

    w = state_dict.get(f'base.{idx}.weight')
    if w is not None and w.ndim == 4 and tuple(w.shape) == (64, 3, 7, 7):
        return 'conv1'

    conv1 = state_dict.get(f'base.{idx}.0.conv1.weight')
    if conv1 is None:
        return None
    shape = tuple(conv1.shape)
    if shape == (64, 64, 3, 3):
        return 'layer1'
    if shape == (128, 64, 3, 3):
        return 'layer2'
    if shape == (256, 128, 3, 3):
        return 'layer3'
    if shape == (512, 256, 3, 3):
        return 'layer4'
    return None


def remap_spumix_state_dict(state_dict):
    """
    Remap older ResNet Sequential checkpoints (MixStyle/SPUMix registered before bn1)
    onto the current forward-order SPUMix Sequential indices.
    """
    base_idxs = sorted({
        int(m.group(1))
        for k in state_dict
        for m in [re.match(r'^base\.(\d+)\.', k)]
        if m
    })
    if not base_idxs:
        return state_dict

    role_to_src = {}
    for idx in base_idxs:
        role = _classify_base_index(state_dict, idx)
        if role is not None:
            role_to_src[role] = idx

    needed = set(_TARGET_BASE)
    if not needed.issubset(role_to_src):
        return state_dict

    # Already in the target layout
    if all(role_to_src[role] == dst for role, dst in _TARGET_BASE.items()):
        return state_dict

    idx_map = {role_to_src[role]: dst for role, dst in _TARGET_BASE.items()}
    remapped = OrderedDict()
    for key, value in state_dict.items():
        m = re.match(r'^base\.(\d+)\.(.*)$', key)
        if not m:
            remapped[key] = value
            continue
        src_idx = int(m.group(1))
        if src_idx not in idx_map:
            # Drop param-free / obsolete Sequential slots (old MixStyle indices, etc.)
            continue
        remapped[f'base.{idx_map[src_idx]}.{m.group(2)}'] = value
    return remapped


def load_model_state_dict(model, checkpoint_path, map_location='cuda', strict=True):
    state_dict = torch.load(checkpoint_path, map_location=map_location)
    if isinstance(state_dict, dict) and 'state_dict' in state_dict:
        state_dict = state_dict['state_dict']
    state_dict = remap_spumix_state_dict(state_dict)
    incompatible = model.load_state_dict(state_dict, strict=strict)
    return incompatible
