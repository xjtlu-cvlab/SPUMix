import os
os.environ['OMP_NUM_THREADS'] = '1'
import argparse
import sys
import datetime
import tqdm
import random
import numpy as np
import torch
from torch.utils.data import DataLoader
from multiview_detector.datasets import *
from multiview_detector.models.mvdetr import MVDeTr
from multiview_detector.utils.logger import Logger
from multiview_detector.trainer import PerspectiveTrainer
from multiview_detector.utils.str2bool import str2bool
import glob

def seed_worker(worker_id):
    worker_seed = torch.initial_seed() % 2 ** 32
    np.random.seed(worker_seed)
    random.seed(worker_seed)

def main(args):
    # seed
    if args.seed is not None:
        random.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)
        torch.cuda.manual_seed(args.seed)
        torch.cuda.manual_seed_all(args.seed)

    # deterministic
    if args.deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        torch.autograd.set_detect_anomaly(True)
    else:
        torch.backends.cudnn.benchmark = True

    # 加载 Wildtrack 数据集（最后10%作为测试集）
    print('加载 Wildtrack 数据集...')
    base = Wildtrack(os.path.expanduser('Data/Wildtrack'))
    
    # 创建测试集（最后10%的数据，train_ratio=0.9 意味着最后10%）
    test_set = frameDataset(base, train=False, world_reduce=args.world_reduce,
                            img_reduce=args.img_reduce, world_kernel_size=args.world_kernel_size,
                            img_kernel_size=args.img_kernel_size, train_ratio=0.9)
    
    test_loader = DataLoader(test_set, batch_size=args.batch_size, shuffle=False, 
                            num_workers=args.num_workers, pin_memory=True, worker_init_fn=seed_worker)

    # 创建模型（需要训练集来初始化模型结构）
    train_set = frameDataset(base, train=True, world_reduce=args.world_reduce,
                            img_reduce=args.img_reduce, world_kernel_size=args.world_kernel_size,
                            img_kernel_size=args.img_kernel_size, train_ratio=0.9)
    
    model = MVDeTr(train_set, args.arch, world_feat_arch=args.world_feat,
                   bottleneck_dim=args.bottleneck_dim, outfeat_dim=args.outfeat_dim,
                   droupout=args.dropout, spumix_p=args.spumix_p,
                   spumix_alpha=args.spumix_alpha).cuda()

    # 查找 multiviewx_epoch 文件夹中的模型文件
    model_dir = args.model_dir
    if not os.path.exists(model_dir):
        print(f'错误: 模型文件夹 {model_dir} 不存在!')
        return
    
    # 查找所有 epoch 模型文件
    model_files = []
    for epoch in range(1, 11):  # 10个epoch
        model_path = os.path.join(model_dir, f'MultiviewDetector_epoch_{epoch}.pth')
        if os.path.exists(model_path):
            model_files.append((epoch, model_path))
        else:
            print(f'警告: 未找到 epoch {epoch} 的模型文件: {model_path}')
    
    if len(model_files) == 0:
        print(f'错误: 在 {model_dir} 中未找到任何模型文件!')
        return
    
    print(f'找到 {len(model_files)} 个模型文件')
    
    # 创建结果目录
    date_time_now = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    result_dir = f'test_results/multiviewx_on_wildtrack-{date_time_now}'
    os.makedirs(result_dir, exist_ok=True)
    sys.stdout = Logger(os.path.join(result_dir, 'output.log'))
    
    print(f'结果将保存到: {result_dir}')
    print(f'测试数据集: Wildtrack (最后10%)')
    print(f'模型来源: {model_dir}')
    print('=' * 80)
    
    # 存储所有结果
    results_summary = []
    
    # 对每个模型进行测试
    for epoch, model_path in sorted(model_files):
        print(f'\n{"="*80}')
        print(f'测试 Epoch {epoch} 模型: {model_path}')
        print(f'{"="*80}')
        
        # 加载模型权重
        try:
            model.load_state_dict(torch.load(model_path, map_location='cuda'))
            model.eval()
            print(f'成功加载模型: {model_path}')
        except Exception as e:
            print(f'错误: 加载模型失败 {model_path}: {e}')
            continue
        
        # 创建 trainer
        trainer = PerspectiveTrainer(model, result_dir, args.cls_thres, args.alpha, 
                                    args.use_mse, args.id_ratio)
        
        # 测试
        epoch_res_fpath = os.path.join(result_dir, f'wildtrack_test_epoch_{epoch}.txt')
        print(f'开始测试...')
        test_loss, moda = trainer.test(epoch, test_loader, epoch_res_fpath, visualize=False)
        
        # 保存结果摘要
        results_summary.append({
            'epoch': epoch,
            'model_path': model_path,
            'test_loss': test_loss,
            'moda': moda
        })
        
        print(f'Epoch {epoch} 测试完成: Loss={test_loss:.6f}, MODA={moda:.1f}%')
    
    # 保存结果摘要
    print(f'\n{"="*80}')
    print('测试结果摘要:')
    print(f'{"="*80}')
    summary_fpath = os.path.join(result_dir, 'test_summary.txt')
    with open(summary_fpath, 'w', encoding='utf-8') as f:
        f.write('Epoch\tTest Loss\tMODA (%)\n')
        f.write('-' * 50 + '\n')
        for result in results_summary:
            f.write(f"{result['epoch']}\t{result['test_loss']:.6f}\t{result['moda']:.1f}\n")
            print(f"Epoch {result['epoch']:2d}: Loss={result['test_loss']:.6f}, MODA={result['moda']:.1f}%")
    
    print(f'\n所有测试完成! 结果已保存到: {result_dir}')
    print(f'摘要文件: {summary_fpath}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='在 Wildtrack 数据集上测试 MultiviewX 训练的模型')
    parser.add_argument('--model_dir', type=str, default='multiviewx_epoch',
                       help='包含训练好的模型文件的目录')
    parser.add_argument('--cls_thres', type=float, default=0.6)
    parser.add_argument('--alpha', type=float, default=1.0, help='ratio for per view loss')
    parser.add_argument('--use_mse', type=str2bool, default=False)
    parser.add_argument('--id_ratio', type=float, default=0)
    parser.add_argument('--arch', type=str, default='resnet18', choices=['vgg11', 'resnet18', 'mobilenet'])
    parser.add_argument('-j', '--num_workers', type=int, default=8)
    parser.add_argument('-b', '--batch_size', type=int, default=1, help='input batch size for testing')
    parser.add_argument('--dropout', type=float, default=0.0)
    parser.add_argument('--seed', type=int, default=2021, help='random seed')
    parser.add_argument('--deterministic', type=str2bool, default=False)
    parser.add_argument('--spumix_p', type=float, default=0.5,
                        help='SPUMix mixing probability P')
    parser.add_argument('--spumix_alpha', type=float, default=0.1,
                        help='SPUMix Beta distribution parameter alpha')
    parser.add_argument('--world_feat', type=str, default='deform_trans',
                       choices=['conv', 'trans', 'deform_conv', 'deform_trans', 'aio'])
    parser.add_argument('--bottleneck_dim', type=int, default=128)
    parser.add_argument('--outfeat_dim', type=int, default=0)
    parser.add_argument('--world_reduce', type=int, default=4)
    parser.add_argument('--world_kernel_size', type=int, default=10)
    parser.add_argument('--img_reduce', type=int, default=12)
    parser.add_argument('--img_kernel_size', type=int, default=10)
    
    args = parser.parse_args()
    main(args)

